import React from 'react'

const Searchbar = () => {
  return (
    <div>Searchbar</div>
  )
}

export default Searchbar