import React,{useContext} from 'react'
import './Payment.css'
import pic1 from './pic1.png'
import pic2 from './pic2.png'
import pic3 from './pic3.jpg'
import pic4 from './pic4.png'
import {StoreContext} from '../../context/StoreContext';

const Payment = () => {

  const{getTotalCartAmount} = useContext(StoreContext);

  return (
    <div className='payment'>
      <p>Total Amount</p>
      <h2>{getTotalCartAmount()+30}</h2>
      <p>Pay Via</p>
      <div className='payment-images'>
        <img src={pic1} alt="pay-pics"/>
        <img src={pic2} alt="pay-pics"/>
        <img src={pic3} alt="pay-pics"/>
        <img src={pic4} alt="pay-pics"/>
      </div>
    </div>
  )
}

export default Payment;